$(document).ready(function(){
	
	$('#profile_ripple').ripples({
		resolution:512,
		dropRadius:10
	});
});